MYDRAMALIST_WEBSITE = "https://mydramalist.com/"  # MyDramaList.com
